package com.example.myapplication;

import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class AddEditActivity extends AppCompatActivity {
    private TextView tvAdd;
    private TextView tvTitle;
    private EditText etName;
    private EditText etAddress;
    private TextView etTime;
    private List<DataBean> dataBeans = new ArrayList<>();
    private int flag = 0; // 0 添加  1修改
    private int position = 0;//  第几条数据

    private DataInfoDao dataInfoDao;
    private String weekStr = "", timeStr = "";
    private int type = 0;
    String week = "";
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit);

        // 取类型值
        flag = getIntent().getIntExtra("flag", 0);
        //  取列表的第几条数据
        position = getIntent().getIntExtra("position", 0);
        type = getIntent().getIntExtra("type",0);
        switch (type) {
            case 0:
                weekStr = "周一";
                break;
            case 1:
                weekStr = "周二";
                break;
            case 2:
                weekStr = "周三";
                break;
            case 3:
                weekStr = "周四";
                break;
            case 4:
                weekStr = "周五";
                break;
        }
        dataInfoDao = new DataInfoDao(this);
        // 取数据
        dataBeans = dataInfoDao.queryAll(weekStr);

        // 初始化控件
        tvAdd = (TextView) findViewById(R.id.tv_add);
        tvTitle = (TextView) findViewById(R.id.tv_title);
        etName = (EditText) findViewById(R.id.et_name);
        etAddress = (EditText) findViewById(R.id.et_address);
        etTime = findViewById(R.id.et_time);
        if (flag == 0) {
            tvTitle.setText("添加课程数据");
        } else {
            tvTitle.setText("修改课程数据");

            // 把上一页的值传到这一页 页面显示
            etName.setText(dataBeans.get(position).getName());
            etAddress.setText(dataBeans.get(position).getAddress());
            etTime.setText(dataBeans.get(position).getTime());
            weekStr = dataBeans.get(position).getWeek();
            timeStr = dataBeans.get(position).getTime();
        }

        tvAdd.setOnClickListener(new View.OnClickListener() {// 添加或修改数据
            @Override
            public void onClick(View view) {
                if (flag == 0) {
                    // 添加数据
                    DataBean dataBean = new DataBean();
                    dataBean.setName(etName.getText().toString());
                    dataBean.setAddress(etAddress.getText().toString());
                    dataBean.setWeek(weekStr);
                    dataBean.setTime(timeStr);
                    dataInfoDao.add(dataBean);
                } else {
                    // 修改数据
                    DataBean dataBean = new DataBean();
                    dataBean.setName(etName.getText().toString());
                    dataBean.setAddress(etAddress.getText().toString());
                    dataBean.setWeek(weekStr);
                    dataBean.setTime(timeStr);
                    dataInfoDao.update(dataBean);
                }
                finish();
            }
        });
        etTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar calendar = Calendar.getInstance();
                TimePickerDialog timePickerDialog = new TimePickerDialog(AddEditActivity.this,
                        (timePicker, hourOfDay, minute) -> {
                            etTime.setText(hourOfDay + ":" + minute);
                            timeStr =hourOfDay + ":" + minute;
                        },
                        calendar.get(Calendar.HOUR_OF_DAY),
                        calendar.get(Calendar.MINUTE),
                        true);

                timePickerDialog.show();
            }
        });
    }
}
