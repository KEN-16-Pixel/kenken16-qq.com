package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private Button bt_1, bt_2, bt_3, bt_4, bt_5;
    private List<DataBean> dataBeans = new ArrayList<>();
    private DataInfoDao dataInfoDao;
    private int type;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bt_1 = findViewById(R.id.bt_1);
        bt_2 = findViewById(R.id.bt_2);
        bt_3 = findViewById(R.id.bt_3);
        bt_4 = findViewById(R.id.bt_4);
        bt_5 = findViewById(R.id.bt_5);
        dataInfoDao = new DataInfoDao(this);

        bt_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle bundle = new Bundle();
                bundle.putInt("type", 0);
                Intent intent = new Intent(MainActivity.this, ManagerActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
        bt_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle bundle = new Bundle();
                bundle.putInt("type", 1);
                Intent intent = new Intent(MainActivity.this, ManagerActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
        bt_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle bundle = new Bundle();
                bundle.putInt("type", 2);
                Intent intent = new Intent(MainActivity.this, ManagerActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
        bt_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle bundle = new Bundle();
                bundle.putInt("type", 3);
                Intent intent = new Intent(MainActivity.this, ManagerActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
        bt_5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle bundle = new Bundle();
                bundle.putInt("type", 4);
                Intent intent = new Intent(MainActivity.this, ManagerActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });

        final Calendar c = Calendar.getInstance();
        c.setTimeZone(TimeZone.getTimeZone("GMT+8:00"));
        String mWay = String.valueOf(c.get(Calendar.DAY_OF_WEEK));
        if ("1".equals(mWay)) {
            mWay = "周天";
        } else if ("2".equals(mWay)) {
            mWay = "周一";
            type = 0;
        } else if ("3".equals(mWay)) {
            mWay = "周二";
            type = 1;
        } else if ("4".equals(mWay)) {
            mWay = "周三";
            type = 2;
        } else if ("5".equals(mWay)) {
            mWay = "周四";
            type = 3;
        } else if ("6".equals(mWay)) {
            mWay = "周五";
            type = 4;
        } else if ("7".equals(mWay)) {
            mWay = "周六";
        }
        dataBeans.clear();
        dataBeans.addAll(dataInfoDao.queryAll(mWay));
        if (dataBeans.size() > 0) {
            Bundle bundle = new Bundle();
            bundle.putInt("type", type);
            Intent intent = new Intent(MainActivity.this, ManagerActivity.class);
            intent.putExtras(bundle);
            startActivity(intent);
        }
    }

}