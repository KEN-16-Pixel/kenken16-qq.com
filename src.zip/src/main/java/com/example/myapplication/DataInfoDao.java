package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class DataInfoDao {

    //数据库帮助类对象
    private MySqliteOpenHelper mySqliteOpenHelper;

    //构造函数
    public DataInfoDao(Context context) {
        mySqliteOpenHelper = new MySqliteOpenHelper(context);
    }

    public boolean add(DataBean dataBean) {
        //创建数据库
        SQLiteDatabase db = mySqliteOpenHelper.getReadableDatabase();
        ContentValues values = new ContentValues();//用map封装的对象，存放值
        values.put("name", dataBean.getName());
        values.put("address", dataBean.getAddress());
        values.put("week", dataBean.getWeek());
        values.put("time", dataBean.getTime());
        //table: 表名 , nullColumnHack：可以为空，标示添加一个空行, values:数据一行的值 , 返回值：代表添加这个新行的Id ，-1代表添加失败
        long result = db.insert("info", null, values);  //返回值是新增的行的id, 失败是-1
        //关闭数据库对象
        db.close();
        if (result != -1) {  //添加成功
            return true;
        } else {
            return false;
        }
    }

    public void del(String name) {
        //创建数据库,调用getReadableDatabase方法,来初始化数据库的创建
        SQLiteDatabase db = mySqliteOpenHelper.getReadableDatabase();
        //执行sql语句
        //db.execSQL("delete from info where name=?;",new Object[]{name});
        //table ：表名, whereClause: 删除条件, whereArgs：条件的占位符的参数 ; 返回值：成功删除多少行
        db.delete("info", "name=?", new String[]{name});
        //关闭数据库对象
        db.close();
    }

    public int update(DataBean dataBean) {
        //创建数据库
        SQLiteDatabase db = mySqliteOpenHelper.getReadableDatabase();
        //执行sql语句
        ContentValues values = new ContentValues();//是用map封装的对象，用来存放值
        values.put("name", dataBean.getName());
        values.put("address", dataBean.getAddress());
        values.put("week", dataBean.getWeek());
        values.put("time", dataBean.getTime());
        //table:表名, values：更新的值, whereClause:更新的条件, whereArgs：更新条件的占位符的值,返回值：成功修改多少行
        int result = db.update("info", values, "name=?", new String[]{dataBean.name});//name=? where的条件
        //关闭数据库对象
        db.close();
        return result;//返回成功的行数
    }

    public ArrayList<DataBean> queryAll(String week) {
        ArrayList<DataBean> list = new ArrayList<DataBean>();
        //创建数据库
        SQLiteDatabase db = mySqliteOpenHelper.getReadableDatabase();

        //执行sql语句，返回一个cursor对象，游标对象
        //Cursor cursor = db.rawQuery("select _id,name,phone from info where name=?", new String[]{name});
        //table:表名, columns：查询的列名,如果null代表查询所有列； selection:查询条件, selectionArgs：条件占位符的参数值,		　　
        //groupBy:按什么字段分组, having:分组的条件, orderBy:按什么字段排序
        Cursor cursor = db.rawQuery("select * from info where week=?", new String[]{week});

        if (cursor != null && cursor.getCount() > 0) {
            //循环遍历结果，获取每一行的 值
            while (cursor.moveToNext()) {
                DataBean dataBean = new DataBean();
                dataBean.id = cursor.getInt(0) + "";
                dataBean.name = cursor.getString(1);
                dataBean.address = cursor.getString(2);
                dataBean.week = cursor.getString(3);
                dataBean.time = cursor.getString(4);
                list.add(dataBean);
            }
            cursor.close();//关闭结果集
        }
        //关闭数据库对象
        db.close();
        return list;
    }
}