package com.example.myapplication;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/**
 * 创建日期：2022/12/17
 * 描述：
 */
public class ManagerActivity extends AppCompatActivity {
    private Button tv_add;
    private RecyclerView recyclerView;
    private List<DataBean> dataBeans = new ArrayList<>();
    private List<DataBean> dataBeansCopy = new ArrayList<>();// 备份数据
    private DataInfoDao dataInfoDao;
    private ItemAdapter itemAdapter;
    private int type;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manager);
        type = getIntent().getIntExtra("type", type);
        dataInfoDao = new DataInfoDao(this);
        tv_add = findViewById(R.id.tv_add);
        recyclerView = findViewById(R.id.mRecyclerView);
        itemAdapter = new ItemAdapter(this, dataBeans, new ItemAdapter.OnItemClickListener() {
            @Override
            public void onLongClick(int pos) { // 长按item

                AlertDialog.Builder builder = new AlertDialog.Builder(ManagerActivity.this);
                builder.setMessage("确定删除吗");
                builder.setTitle("提示");
                builder.setPositiveButton("确定",
                        new android.content.DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dataInfoDao.del(dataBeans.get(pos).getName());
                                dataBeans.remove(pos);
                                itemAdapter.notifyDataSetChanged();
                            }
                        });
                builder.setNegativeButton("取消",
                        new android.content.DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                builder.create().show();
            }

            @Override
            public void onItemClick(int pos) { // 点击item
                Intent intent = new Intent();
                Bundle bundle = new Bundle();
                bundle.putInt("flag", 1);// 传0表示修改
                bundle.putInt("type", type);
                bundle.putInt("position", pos);
                intent.putExtras(bundle);
                intent.setClass(ManagerActivity.this, AddEditActivity.class);
                startActivity(intent);
            }
        });

        // 首页列表展示
        recyclerView = findViewById(R.id.mRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        // 设置适配器
        recyclerView.setAdapter(itemAdapter);

        tv_add = findViewById(R.id.tv_add);
        tv_add.setOnClickListener(new View.OnClickListener() {// 添加数据
            @Override
            public void onClick(View view) {
                // 添加按钮点击监听，跳转到AddEditActivity页面，传参数type 0
                Intent intent = new Intent();
                Bundle bundle = new Bundle();
                bundle.putInt("flag", 0);// 传0表示添加
                bundle.putInt("type", type);
                intent.putExtras(bundle);
                intent.setClass(ManagerActivity.this, AddEditActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        // 获取数据
        String week = "";
        switch (type) {
            case 0:
                week = "周一";
                break;
            case 1:
                week = "周二";
                break;
            case 2:
                week = "周三";
                break;
            case 3:
                week = "周四";
                break;
            case 4:
                week = "周五";
                break;
        }
        dataBeansCopy = dataInfoDao.queryAll(week);
        dataBeans.clear();
        dataBeans.addAll(dataBeansCopy);
        sortData(dataBeans);
        // 刷新界面
        itemAdapter.notifyDataSetChanged();
        super.onResume();
    }

    public static Date stringToDate(String dateString) {
        ParsePosition position = new ParsePosition(0);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm");
        Date dateValue = simpleDateFormat.parse(dateString, position);
        return dateValue;
    }

    private List<DataBean> sortData(List<DataBean> mList) {
        Collections.sort(mList, new Comparator<DataBean>() {
            @Override
            public int compare(DataBean lhs, DataBean rhs) {
                Date date1 = stringToDate(lhs.getTime());
                Date date2 = stringToDate(rhs.getTime());
                // 对日期字段进行升序，如果欲降序可采用after方法
                if (date1.after(date2)) {
                    return 1;
                }
                return -1;
            }
        });
        return mList;
    }
}
