package com.example.myapplication;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

/**
 * @author CSY
 * 创建日期：2022/9/6
 * 描述：
 */
public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {

    //定义所需传入的参数
    private List<DataBean> mDatas;
    private Context context;
    private OnItemClickListener listener;

    //初始化Adapter时传入相关参数
    public ItemAdapter(Context context, List<DataBean> users, OnItemClickListener listener) {
        this.mDatas = users;
        this.context = context;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //使每一个RecycleView中的视图都显示为R.layout.item的样式
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_note, parent, false));
    }

    // 首页列表渲染数据适配器
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        // 设置标题和内容
        holder.tvTitle.setText(mDatas.get(position).getName());
        holder.tvContent.setText("科目：" + mDatas.get(position).getName() + "\n" +
                "上课地点：" + mDatas.get(position).getAddress() + "\n" +
                "上课时间：" + mDatas.get(position).getWeek() + " " + mDatas.get(position).getTime());

        // 点击item
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onItemClick(position);
            }
        });

        // 长按item
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                listener.onLongClick(position);
                return false;
            }
        });
    }


    @Override
    public int getItemCount() {
        //返回List的大小，使其全部显示
        return mDatas.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        private TextView tvTitle, tvContent;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            //定位要设置的控件
            tvTitle = itemView.findViewById(R.id.tv_title);
            tvContent = itemView.findViewById(R.id.tv_content);
        }
    }

    public interface OnItemClickListener {
        //在初始化时获得事件
        void onLongClick(int pos);

        void onItemClick(int pos);
    }
}